/**
 * @namespace afw
 */
var afw = {};