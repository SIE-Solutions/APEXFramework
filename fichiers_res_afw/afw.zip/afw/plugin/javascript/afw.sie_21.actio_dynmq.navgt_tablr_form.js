afw.sie_21.actio_dynmq.navgt_tablr_form = {
  initl : function () {
    //voir afw_legacy.js
    afw.jQuery(document).keydown(checkUpDownKey);
  }
}