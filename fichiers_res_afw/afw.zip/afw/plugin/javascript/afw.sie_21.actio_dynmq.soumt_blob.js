﻿/*
/**
 * @namespace afw.sie_21.actio_dynmq.soumt_blob
 */
afw.sie_21.actio_dynmq.soumt_blob = {
  insta : [],
  obten : function(pnu_id) {
    for( i = 0; i < afw.sie_21.actio_dynmq.soumt_blob.insta.length; i++) {
      if(afw.sie_21.actio_dynmq.soumt_blob.insta[i].id == pnu_id) {
        return afw.sie_21.actio_dynmq.soumt_blob.insta[i];
      }
    }
  },
  suprm : function(pnu_id) {
    for( i = 0; i < afw.sie_21.actio_dynmq.soumt_blob.insta.length; i++) {
      if(afw.sie_21.actio_dynmq.soumt_blob.insta[i].id == pnu_id) {
        afw.sie_21.actio_dynmq.soumt_blob.insta.splice(i, 1);
      }
    }
  },
  /**
   * @constructor
   */
  soumt_blob : function(pjs_optio, pjs_calbc) {
    this.jQuery               = afw.jQuery;
    var that                  = this;
    this.id                   = false;
    this.initl                = initl;
    this._telvr_blob          = _telvr_blob;
    this._telvr_fichr         = _telvr_fichr;    
    this._creer_colct_blob    = _creer_colct_blob;    

    this.optio = {
      vnu_id_actio_dynmq : "",
      vva_html_id_actio_dynmq : "",
      vva_nom_plugn : "",
      vva_reqt_soums_page : "",
      var_liste_items : [],
      vbo_ckedt : true,
      vva_plugn_ajax : ""
    };

    this.initl(pjs_optio);

    return that;

    function initl(pjs_optio) {
      //fusionner les options passées en paramètre et leurs valeurs par défaut
      that.optio = that.jQuery.extend(true, that.optio, pjs_optio);

      that.id = that.optio.vva_html_id_actio_dynmq;

      var vva_evenm_termn = "soumt_" + that.optio.vva_reqt_soums_page + ((that.optio.vva_reqt_soums_page != "") ? "_" : "") + "blob_termn";

      that.jQuery(document).bind(vva_evenm_termn, function(event, ui) {
        // apex.event.trigger(that.jQuery(document),event.type+that.optio.vva_nom_plugn);
      });
      
      that._creer_colct_blob();
      that.jQuery(document).trigger(vva_evenm_termn);

    }; //END initl
    
    function _telvr_blob(p_fichr, pnu_index) {
      var lectr_fichr = new FileReader();
      
      lectr_fichr.onprogress = function(evenm) {
        if ( evenm.lengthComputable ) {
          var progress = that.jQuery("progress" ,"#fichr_"+p_fichr.seqnc).get(0);
          progress.setAttribute('value', evenm.loaded);
          progress.setAttribute('max', evenm.total);
        }
      };
      
      lectr_fichr.onload = function(evenm) {
      };
      
      lectr_fichr.onloadend = function(evenm) {
        var var_blob = $s_Split(evenm.target.result, 4000);
       
        afw.jQuery.exec_aplic_procs({
          "plugn_ajax" : that.optio.vva_plugn_ajax,
          "procs_retrn_data_type" : "text",
          "widget_action" : "TELVS_BLOB",
          "x01" : p_fichr.fichr.name,
          "x02" : p_fichr.fichr.type,
          "f01" : var_blob,
          "sucs_procs" : function(pjs_data) {
            afw.sie_21.regn.telvr_fichr.insta[0].var_liste_fichr.liste_fichr.splice(pnu_index, 1);
            
            if ( evenm.lengthComputable ) {
              var progress = that.jQuery("progress" ,"#fichr_"+p_fichr.seqnc).get(0);
              progress.setAttribute('value', evenm.total);
              progress.setAttribute('max', evenm.total);
              that.jQuery("progress" ,"#fichr_"+p_fichr.seqnc).after("100%");
            }
          }
        });
      };
      
      // Lecture du fichier
      //lectr_fichr.readAsBinaryString(p_fichr.fichr);
      lectr_fichr.readAsText(p_fichr.fichr);
      
    }; //END _telvr_blob

    function _telvr_fichr() {
      //TODO::CARLO      
      that.jQuery(afw.sie_21.regn.telvr_fichr.insta[0].var_liste_fichr.liste_fichr).each(function(i, fichr){
        if (fichr.indic_a_telvr ) {
          that._telvr_blob(fichr, i);
        }
      });
      
      /*for (var i = 0, fichr; fichr = var_liste_fichr[i]; i++) {
        fichr = var_liste_fichr[i];
        that._telvr_blob(fichr, i);
      }*/
    }; //END _telvr_fichr

    function _creer_colct_blob() {
      afw.jQuery.exec_aplic_procs({
        "plugn_ajax" : that.optio.vva_plugn_ajax,
        "widget_action" : "CREER_COLCT_BLOB",
        "sucs_procs" : function(pjs_data) {
          that._telvr_fichr();
        }
      });
    }; //END _creer_colct_blob

    return that;
  } //END soumt_blob
}