/*
 * APEX Themes - Themes, Templates & Skins for Oracle APEX Applications
 * http://www.apex-themes.com
 * Copyright (c) 2011 Creative Mode
 * This file is protected by copyright law and provided under license.
 * Unauthorised copying of this file is strictly prohibited.
 */

/* LAYOUT */
var pageLayout;

var layout = {
	'westSidebar' : {
		west__paneSelector: '#echo-sidebar-west',
		west__size: 250, // APEXFramework 2011-09-27
		west__resizable: true // APEXFramework
	},
	'eastSidebar' : {
		east__paneSelector: '#echo-sidebar-east',
		east__size: 250 // APEXFramework 2011-09-27
	},
	'westSidebarRTL' : {
		west__paneSelector: '#echo-sidebar-east',
		west__size: 270
	},
	'eastSidebarRTL' : {
		east__paneSelector: '#echo-sidebar-west',
		east__size: 270
	},
	'common' : {
		resizable: false, // APEXFramework
		spacing_open: 10,
		spacing_closed: 10,
		north__paneSelector: '#echo-page-header',
		center__paneSelector: '#echo-page-content',
		south__paneSelector: '#echo-page-footer',
    north__closable: false, // APEXFramework
		togglerTip_open: 'Cacher la zone', // APEXFramework
		togglerTip_closed: 'Afficher la zone', // APEXFramework
		resizerTip: 'Redimensionner la zone.' // APEXFramework
		//enableCursorHotkey: false // APEXFramework
	},
	'init' : function () {
  
		if (typeof layoutState != 'undefined') {
			// Temporarily disable cookie saving if you are trying to delete the pageLayout cookie, otherwise it will just get resaved when the page unloads.
			// 1) Comment out the line below.
			// 2) Load your page.
			// 3) Delete the cookie.
			// 4) Remove comment.
			$(window).unload( function(){ layoutState.save('pageLayout', 'north__isClosed,west__size,west__isClosed,east__size,east__isClosed') });
		}
					
		switch (apexEnv.pageLayout) {
			case 'sidebar' :
				if(apexEnv.dir == 'rtl') {
					$.extend(layout.common, layout.eastSidebarRTL);
				} else {
          //$.extend(layout.common, layout.eastSidebar); //APEXFramework
          $.extend(layout.common, layout.westSidebar);
				}
				break;
			case 'twoSidebars' :
				if(apexEnv.dir == 'rtl') {
					$.extend(layout.common, layout.westSidebarRTL, layout.eastSidebarRTL);
				} else {
					$.extend(layout.common, layout.westSidebar, layout.eastSidebar);
				}
				break;
		}
		
		pageLayout = $('body').addClass('echo-layout-' + apexEnv.pageLayout).layout($.extend(layout.common, layoutState.load('pageLayout')));
	}
};

var theme = {
	'init' : function () {
		/* FORMS */
		theme.formatForms();
	
		/* REPORTS */
		theme.formatReports();
		
    
    /* NOTE APEXFramework: annuler ces événements */
    /*
    $('tr.echo-report-row').live('mouseenter', function () {
    $(this).children('td:not(.echo-separator)').addClass('ui-state-highlight');
    });
    $('tr.echo-report-row').live('mouseleave', function () {
    $(this).children('td:not(.echo-separator)').removeClass('ui-state-highlight');
    });
    */
    
    /* HOVER STATE */
    $('.echo-control, .echo-button, .echo-tab, .echo-image-container, .echo-report-header:has(a), .echo-submenu a').live('mouseenter', function () {
    $(this).addClass('ui-state-hover');
    });
    $('.echo-control, .echo-button, .echo-tab, .echo-image-container, .echo-report-header:has(a), .echo-submenu a').live('mouseleave', function () {
    $(this).removeClass('ui-state-hover');
    });
		
		/* PULL DOWN MENUS */
		var dir = 'left';
		if ( typeof apexEnv.dir == 'string' && apexEnv.dir == 'rtl' ) { dir = 'right'; }
		
		$('div.echo-menu-pull-down > ul').mouseenter(function () {
			if(pageLayout && pageLayout.allowOverflow) {pageLayout.allowOverflow(this);}
		}).mouseleave(function () {
			if(pageLayout && pageLayout.resetOverflow) {pageLayout.resetOverflow(this);}
		});	
		
		$('div.echo-menu-pull-down > ul > li.echo-has-submenu').mouseenter(function () {
			var obj = $(this);
			// IE7 fix (see http://mahzeh.org/?p=23)
			$('div.echo-menu').css('z-index', 0);
			obj.closest('div.echo-menu').css('z-index', 999999);

			if (obj.children('ul.echo-submenu').css('display') == 'none') {
				obj.children('ul.echo-submenu').css(dir, 0).css({'top' : obj.height(), 'z-index' : 99}).show();
			}
		}).mouseleave(function () {
			$('ul.echo-submenu').hide();
		});	
			
		$('ul.echo-submenu > li.echo-has-submenu').mouseenter(function () {
			var obj = $(this);		
			if (obj.children('ul.echo-submenu').css('display') == 'none') {
				obj.children('ul.echo-submenu').css(dir, obj.width()).css({'top' : 0, 'z-index' : 99}).show();
			}
		}).mouseleave(function () {
			$(this).children('ul.echo-submenu').hide();
		});
	
		/* HIERARCHICAL EXPANDING LIST */
		$('div.echo-list-hierarchical-expanding a.echo-button').click(function () {
			$(this).children('span').toggleClass('ui-icon-minusthick ui-icon-plusthick');
			$(this).nextAll('ul.echo-sublist').slideToggle('fast');
			return false;
		});
		$('div.echo-list-hierarchical-expanding li.echo-current').parents().andSelf().children('a.echo-button').click();
		
		/* HIDE/SHOW REGIONS */
		/*$('div.echo-region-hideshow div.echo-region-title a.echo-button:first-child').click(function () {
			$(this).children('span').toggleClass('ui-icon-circle-triangle-n ui-icon-circle-triangle-s');
			$(this).closest('div.echo-region').find('div.echo-hideshow-container').slideToggle('fast');
			return false;
		});*/
		
		/* REGION DISPLAY SELECTOR */
		$('div.apex-rds-container').addClass('echo-region ui-widget-content ui-corner-all echo-list echo-button-list').click(function (e) {
			$(this).find('a').removeClass('echo-current ui-state-active');
			$(e.target).parent('a').addClass('echo-current ui-state-active');
		});
		$('div.apex-rds-container > ul').addClass('clearfix');
		$('div.apex-rds-container > ul > li > a').addClass('echo-button echo-button1 ui-state-default ui-corner-all');
		$('div.apex-rds-container > ul > li.apex-rds-selected > a').addClass('echo-current ui-state-active');
		
		/* INTERACTIVE REPORTS */
		$('head').append('<style type="text/css" title="apexir"></style>');
		var sheet = document.styleSheets[document.styleSheets.length - 1];
	
		$('table.apexir_WORKSHEET_DATA th > div[onclick]').live('click', function () {
			$('style[title=apexir]').remove();
			$('head').append('<style type="text/css" title="apexir"></style>');
			var sheet = document.styleSheets[document.styleSheets.length - 1];
			pos = $(this).position();
			pos.top += $(this).parent().height();
			theme.addCssRule(sheet, '#apexir_rollover', 'left:' + pos.left + 'px!important;top:' + pos.top + 'px!important;');
		});
		
		/* AUTO COMPLETE 
		1.0.2: Added. Autocomplete popup is now appended after autocomplete input with js, to allow scrolling of panel when visible.
		1.0.4: Removed. Fixed a minor scrolling issue with panelled layouts but caused a major positioning bug with CSS-P layouts.
		
		$('input.ac_input').live('keydown keyup', function () {
			if( $('body > div.ac_results').length > 0 ) {
				$('body > div.ac_results').insertAfter(this);
			}			
		});
		*/
		
		/* ERROR PAGE*/
		$('div.ErrorPageMessage').prependTo('div.echo-region-title');
		
		/* OVERLAYS */
		$('#echo-overlay-pageload').fadeOut();		
	},
	'formatForms' : 	function () {
							$('table.formlayout td:not(:has(:visible))').addClass('echo-no-padding');
							$('table.formlayout td:has(:visible)').removeClass('echo-no-padding');
						},
	'formatReports' : function () {
		$('table.echo-report > tbody').each(function () {
			$(this).children('tr:first').not('tr.echo-report-row, :has(td.echo-report-data)').addClass('echo-pagination top').children('td').addClass('ui-widget-header');
			$(this).children('tr:last').not('tr.echo-report-row, :has(td.echo-report-data)').addClass('echo-pagination bottom').children('td').addClass('ui-widget-header');				  
		});
		
		$('tr.echo-pagination:has(td:only-child:empty)').remove();
		$('table.echo-report').attr('cellspacing', 0);
		$('table.echo-report th:not(:has(a, span))').wrapInner('<span></span>');
		$('div.echo-value-attribute-pairs-report tr.echo-report-row:last').filter(':has(td.echo-separator)').remove();
		$('div.echo-report-links').each(function () {
			var obj = $(this);
			obj.prependTo( obj.parent().find('tr.echo-pagination.bottom > td') );  
		});
		
		$('th.echo-report-header a:has(+img)').each(function () {
			$(this).siblings('img').remove();
			if ($(this).attr('href').indexOf('desc') != -1) {
				$(this).append('<span class="ui-icon ui-icon-triangle-1-n echo-column-sort-up"></span>');
			} else {
				$(this).append('<span class="ui-icon ui-icon-triangle-1-s echo-column-sort-down"></span>');
			}
			$(this).parent().addClass('ui-state-active');
		});
	},	
	'labelHelp' : function (currentItemId, sessionId) {
		$('#echo-popup-help').remove();
		$('body').append('<div id="echo-popup-help" title="Help"></div>');
		$('#echo-popup-help').append('<p></p>').load('wwv_flow_item_help.show_help?p_item_id=' + currentItemId + '&p_session=' + sessionId + ' .instructiontext');
		$('#echo-popup-help').dialog();
	},
	'addCssRule' : function (sheet, selector, rule) {
		if (sheet.insertRule){ //if Firefox
			sheet.insertRule(selector + '{' + rule + '}', sheet.cssRules.length)
		}
		else if (sheet.addRule){ //else if IE
			sheet.addRule(selector, rule)
		}
	}
}

$(document).ready( function () {
	if ( typeof apexEnv.pageLayout != 'undefined' && apexEnv.pageLayout != null ) {
		layout.init();
	}
	theme.init();
}).bind('apexafterrefresh', theme.formatReports);