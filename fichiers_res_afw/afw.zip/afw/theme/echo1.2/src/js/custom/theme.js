/*
 * Code qui permet de faire fonctionner les templates complémentaires
 *
 * APEX Themes - Themes, Templates & Skins for Oracle APEX Applications
 * http://www.apex-themes.com
 */

afw.theme.echo_1_2 = {
  'init' : function() {
    /* REPORTS */
    afw.theme.echo_1_2.formatReports();

    /* NAVIGATION BAR PULL DOWN MENUS */
    var dir = 'left';
    if ( typeof apexEnv.dir == 'string' && apexEnv.dir == 'rtl') {
      dir = 'right';
    }

    $('div.echo-menu-pull-down-navgt-bar > ul').mouseenter(function() {
      if (pageLayout && pageLayout.allowOverflow) {
        pageLayout.allowOverflow(this);
      }
    }).mouseleave(function() {
      if (pageLayout && pageLayout.resetOverflow) {
        pageLayout.resetOverflow(this);
      }
    });

    $('div.echo-menu-pull-down-navgt-bar > ul > li.echo-has-submenu').mouseenter(function() {
      var obj = $(this);
      // IE7 fix (see http://mahzeh.org/?p=23)
      $('div.echo-menu').css('z-index', 0);
      obj.closest('div.echo-menu').css('z-index', 999999);

      if (obj.children('ul.echo-submenu').css('display') == 'none') {
        obj.children('ul.echo-submenu').css(dir, 0).css({
          'top' : obj.height(),
          'z-index' : 99,
          'width' : obj.children('.ui-button').width()
        }).show();
      }
    }).mouseleave(function() {
      $('ul.echo-submenu').hide();
    });

    $('ul.echo-submenu > li.echo-has-submenu').mouseenter(function() {
      var obj = $(this);
      if (obj.children('ul.echo-submenu').css('display') == 'none') {
        obj.children('ul.echo-submenu').css(dir, obj.width()).css({
          'top' : 0,
          'z-index' : 99
        }).show();
      }
    }).mouseleave(function() {
      $(this).children('ul.echo-submenu').hide();
    });

    /* PULL DOWN MENUS VERTICAL */
    var dir = 'left';
    if ( typeof apexEnv.dir == 'string' && apexEnv.dir == 'rtl') {
      dir = 'right';
    }

    $('div.echo-menu-pull-down-vertc > ul').mouseenter(function() {
      if (pageLayout && pageLayout.allowOverflow) {
        pageLayout.allowOverflow(this);
      }
    }).mouseleave(function() {
      if (pageLayout && pageLayout.resetOverflow) {
        pageLayout.resetOverflow(this);
      }
    });

    $('div.echo-menu-pull-down-vertc > ul > li.echo-has-submenu').mouseenter(function() {
      var obj = $(this);
      // IE7 fix (see http://mahzeh.org/?p=23)
      $('div.echo-menu').css('z-index', 0);
      obj.closest('div.echo-menu').css('z-index', 999999);

      if (obj.children('ul.echo-submenu').css('display') == 'none') {
        //obj.children('ul.echo-submenu').css(dir, 0).css({'top' : obj.height(), 'z-index' : 99}).show();
        obj.children('ul.echo-submenu').css(dir, obj.width()).css({
          'top' : 0,
          'z-index' : 99
        }).show();
      }
    }).mouseleave(function() {
      $('ul.echo-submenu').hide();
    });

    $('ul.echo-submenu > li.echo-has-submenu').mouseenter(function() {
      var obj = $(this);
      if (obj.children('ul.echo-submenu').css('display') == 'none') {
        obj.children('ul.echo-submenu').css(dir, obj.width()).css({
          'top' : 0,
          'z-index' : 99
        }).show();
      }
    }).mouseleave(function() {
      $(this).children('ul.echo-submenu').hide();
    });

    /* HOVER STATE */
    $('.ui-button').live('mouseenter', function() {
      $(this).addClass('ui-state-hover');
    }).live('mouseleave', function() {
      $(this).removeClass('ui-state-hover');
    });

    $('.apexir_WORKSHEET_DATA tr.even, .apexir_WORKSHEET_DATA tr.odd').live('mouseenter', function() {
      $("td.echo-report-data:not([headers='LINK'])", this).addClass('ui-state-hover');
    }).live('mouseleave', function() {
      $("td.echo-report-data:not([headers='LINK'])", this).removeClass('ui-state-hover');
    });

    $('tr.echo-report-row.highl:gt(0)').live('mouseenter', function() {
      $("td.echo-report-data:not([headers^='LINK$']):not([headers^='DERIVED$'])", this).addClass('ui-state-hover');
      $("td.echo-report-data-alt:not([headers^='LINK$']):not([headers^='DERIVED$'])", this).addClass('ui-state-hover');

    }).live('mouseleave', function() {
      $("td.echo-report-data:not([headers^='LINK$']):not([headers^='DERIVED$'])", this).removeClass('ui-state-hover');
      $("td.echo-report-data-alt:not([headers^='LINK$']):not([headers^='DERIVED$'])", this).removeClass('ui-state-hover');
    });

    /* HIDE/SHOW REGIONS */
    $('div.echo-region-hideshow div.echo-region-title a.echo-button:first-child').click(function() {
      $(this).children('span').toggleClass('fff-icon-arrow-in fff-icon-arrow-out');
      $(this).closest('div.echo-region').find('div.echo-hideshow-container').slideToggle('fast');
      return false;
    });

  },
  'formatReports' : function() {
    $('div.echo-report:not(.echo-report-one-column-unordered-list) table.echo-report > tbody .echo-pagination > td').toggleClass('ui-widget-content ui-widget-header');
    $('div.echo-report.echo-report-one-column-unordered-list table.echo-report > tbody .echo-pagination > td').toggleClass('ui-widget-content ui-widget-header');

    /*Export CSV*/
    var vva_text_report_links = $('.echo-report-links').text();
    var vva_link_report_links = $('.echo-report-links a').attr('href');

    $('.echo-report-links a').replaceWith('<div class="echo-report-links"><span class="small_text_button ui-button ui-widget ui-state-default ui-corner-all ui-button-text-icons"><a href="' + vva_link_report_links + '" title="' + vva_text_report_links + '" alt="' + vva_text_report_links + '"><span class="ui-button-icon-primary ui-icon ui-icon-newwin"></span><span class="ui-button-text">' + vva_text_report_links + '</span></a></span></div>');

    $('th.echo-report-header .rpt-sort a').prepend('<span class="ui-icon ui-icon-gear"></span>');
    $('span.echo-column-sort-up, span.echo-column-sort-down').addClass('echo-column-sort');

    $('th.echo-report-header .rpt-sort.ui-state-active').parent().addClass('ui-state-active');

    //$(".apexir_WORKSHEET_DATA th img[alt='Ascendant'],.apexir_WORKSHEET_DATA th img[alt='Descendant']").parents('th:first').addClass('ui-state-active');
  }
}

$(document).ready(function() {
  afw.theme.echo_1_2.init();
}).bind('apexafterrefresh', afw.theme.echo_1_2.formatReports); 