This folder contains an example custom skin for "Echo" APEX theme to help you create your own custom skins.
Abridged summary of folder contents:

example/
 - css/
  - images/									jQuery UI ThemeRoller images plus custom images.
  jquery.ui.theme.css						The style-only CSS file extracted from the jQuery UI ThemeRoller theme zip file.
  skin.css									The CSS file loaded by UI_THEME_PATH.
 - jquery-ui/								The "base" jQuery UI theme v1.8 as copied from APEX installation.
 jquery-ui.1.8.13.custom.zip				A jQuery UI ThemeRoller theme download file (for reference only).
 
 The file css/skin.css contains detailed instructions on how to further customise this example skin to meet you own design needs.