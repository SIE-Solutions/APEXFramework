/**
 * @namespace afw
 */
var afw = {};